myedit("showXY.R")
